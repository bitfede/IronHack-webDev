require 'test_helper'

class SandwichTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
